# test_mcp.py
import asyncio
from mcp.client.streamable_http import streamablehttp_client
from mcp import ClientSession

async def main():
    async with streamablehttp_client("http://localhost:8000/mcp") as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # List tools
            tools = await session.list_tools()
            print("Tools available:")
            for t in tools.tools:
                print(f"  - {t.name}: {t.description}")

            print("\nChat started! Type 'exit' to quit, 'reset' to clear history.\n")

            while True:
                user_input = input("You: ").strip()

                if not user_input:
                    continue
                if user_input.lower() in ("exit", "quit"):
                    print("Session ended.")
                    break
                if user_input.lower() == "reset":
                    result = await session.call_tool("reset_conversation", {
                        "user_id": "test-user"
                    })
                    print(f"System: {result.content[0].text}\n")
                    continue

                result = await session.call_tool("chat", {
                    "message": user_input,
                    "user_id": "test-user"
                })
                print(f"\nAgent: {result.content[0].text}\n")

asyncio.run(main())