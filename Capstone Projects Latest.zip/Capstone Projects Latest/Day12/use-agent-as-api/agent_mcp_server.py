# agent_mcp_server.py
import os
import logging
import time
import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from collections.abc import AsyncIterator

from mcp.server.fastmcp import FastMCP, Context
from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── App context (initialised once at startup) ────────────────────────
@dataclass
class AppContext:
    client: AIProjectClient
    agent_id: str
    sessions: dict  # user_id -> thread_id

@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Connect to Azure once when the MCP server starts."""
    logger.info("Connecting to Azure AI...")
    client = AIProjectClient.from_connection_string(
        credential=DefaultAzureCredential(),
        conn_str=os.getenv("CONNECTION_STRING")
    )
    agent_id = os.getenv("AGENT_ID")
    client.agents.get_agent(agent_id)  # validate agent exists
    logger.info(f"Connected. Agent: {agent_id}")
    yield AppContext(client=client, agent_id=agent_id, sessions={})

# ── MCP server ───────────────────────────────────────────────────────
mcp = FastMCP(
    "Azure AI Agent",
    instructions="Chat with an Azure AI agent that can answer questions from your data.",
    lifespan=lifespan
)

MAX_RETRIES = 3

def _get_or_create_thread(ctx: AppContext, user_id: str) -> str:
    """Return existing thread for user or create a new one."""
    if user_id not in ctx.sessions:
        thread = ctx.client.agents.create_thread()
        ctx.sessions[user_id] = thread.id
        logger.info(f"New thread {thread.id} for user '{user_id}'")
    return ctx.sessions[user_id]

def _get_latest_reply(ctx: AppContext, thread_id: str) -> str:
    """Fetch the most recent assistant message from the thread."""
    messages = ctx.client.agents.list_messages(thread_id=thread_id)
    for msg in messages.data:
        if msg.role == "assistant":
            for block in msg.content:
                if block.type == "text":
                    text = block.text.value
                    for ann in block.text.annotations:
                        text = text.replace(ann.text, "")
                    return text.strip()
    return "(No response)"


# ── Tool 1: chat ─────────────────────────────────────────────────────
@mcp.tool()
async def chat(message: str, user_id: str = "default-user", context: Context = None) -> str:
    """
    Send a message to the Azure AI agent and get a reply.
    
    Args:
        message:  The user's message or question.
        user_id:  Unique identifier for the user (keeps conversation history separate).
    """
    app: AppContext = context.request_context.lifespan_context
    thread_id = _get_or_create_thread(app, user_id)

    # Send user message
    app.client.agents.create_message(
        thread_id=thread_id,
        role="user",
        content=message
    )

    # Run with retry + exponential back-off
    last_error = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            start = time.time()
            run = await asyncio.to_thread(
                app.client.agents.create_and_process_run,
                thread_id=thread_id,
                agent_id=app.agent_id
            )
            latency = round(time.time() - start, 2)
            logger.info(f"Run {run.id} status={run.status} latency={latency}s user={user_id}")

            if run.status == "failed":
                raise RuntimeError(f"Run failed: {run.last_error}")

            return _get_latest_reply(app, thread_id)

        except Exception as e:
            last_error = e
            logger.warning(f"Attempt {attempt}/{MAX_RETRIES} failed: {e}")
            if attempt < MAX_RETRIES:
                await asyncio.sleep(2 * attempt)  # exponential back-off

    raise RuntimeError(f"All {MAX_RETRIES} attempts failed: {last_error}")


# ── Tool 2: reset_conversation ───────────────────────────────────────
@mcp.tool()
async def reset_conversation(user_id: str = "default-user", context: Context = None) -> str:
    """
    Reset the conversation history for a user by creating a new thread.

    Args:
        user_id: The user whose conversation should be reset.
    """
    app: AppContext = context.request_context.lifespan_context
    thread = app.client.agents.create_thread()
    app.sessions[user_id] = thread.id
    logger.info(f"Reset thread -> {thread.id} for user '{user_id}'")
    return f"Conversation reset. New thread ID: {thread.id}"


# ── Tool 3: get_session_info ─────────────────────────────────────────
@mcp.tool()
async def get_session_info(context: Context = None) -> dict:
    """
    Returns active session info — list of users and their thread IDs.
    Useful for debugging or monitoring active conversations.
    """
    app: AppContext = context.request_context.lifespan_context
    return {
        "agent_id": app.agent_id,
        "active_sessions": app.sessions,
        "session_count": len(app.sessions)
    }


# ── Entry point ──────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    transport = sys.argv[1] if len(sys.argv) > 1 else "stdio"

    if transport == "http":
        import uvicorn
        # MCP 1.26.0 — correct method
        uvicorn.run(
            mcp.streamable_http_app(),
            host="0.0.0.0",
            port=8000
        )
    else:
        mcp.run(transport="stdio")