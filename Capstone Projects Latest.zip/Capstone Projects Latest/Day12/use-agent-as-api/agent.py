from azure.ai.projects import AIProjectClient
from azure.identity import DefaultAzureCredential
import os
from dotenv import load_dotenv

load_dotenv()
 
project_client = AIProjectClient.from_connection_string(
    credential=DefaultAzureCredential(),
    conn_str= os.getenv("CONNECTION_STRING")
)
 
agent = project_client.agents.get_agent(os.getenv("AGENT_ID"))
thread = project_client.agents.create_thread()
print(f"Connected to agent. Thread ID: {thread.id}")
print("Chat started! Type 'exit' or 'quit' to end.\n")
 
while True:
    user_input = input("You: ").strip()
 
    if not user_input:
        continue
 
    if user_input.lower() in ("exit", "quit"):
        print("Ending chat session.")
        break
 
    # Send user message
    project_client.agents.create_message(
        thread_id=thread.id,
        role="user",
        content=user_input
    )
 
    # Run the agent
    run = project_client.agents.create_and_process_run(
        thread_id=thread.id,
        agent_id=agent.id
    )
 
    if run.status == "failed":
        print(f"Run failed: {run.last_error}\n")
        continue
 
    messages = project_client.agents.list_messages(thread_id=thread.id)
 
    # Use .data to get the list of actual message objects
    for msg in messages.data:
        if msg.role == "assistant":
            for block in msg.content:
                if block.type == "text":
                    text = block.text.value
                    for annotation in block.text.annotations:
                        text = text.replace(annotation.text, "")
                    print(f"\nAgent: {text.strip()}\n")
            break  # Only latest assistant message